
import { TradingBot, MarketData, Trade } from '../types/trading';

export const mockBots: TradingBot[] = [
  {
    id: '1',
    name: 'BTC Scalper Pro',
    exchange: 'bybit',
    symbol: 'BTCUSDT',
    status: 'active',
    leverage: 5,
    balance: 5000,
    pnl: 847.32,
    pnlPercentage: 16.95,
    totalTrades: 156,
    winRate: 73.5,
    createdAt: '2024-01-15T10:30:00Z',
    lastTradeAt: '2024-01-20T14:22:00Z',
    riskLevel: 'medium',
    strategy: {
      rsiThreshold: 70,
      adxThreshold: 25,
      bbWidthThreshold: 0.02,
      emaSlope: 0.5,
      atrPercentage: 2.5,
      vwapDistance: 1.2,
      momentumThreshold: 0.8,
      useMLPrediction: true,
      minSamplesForML: 100
    }
  },
  {
    id: '2',
    name: 'ETH Momentum',
    exchange: 'okx',
    symbol: 'ETHUSDT',
    status: 'active',
    leverage: 3,
    balance: 3000,
    pnl: -124.56,
    pnlPercentage: -4.15,
    totalTrades: 89,
    winRate: 68.2,
    createdAt: '2024-01-18T09:15:00Z',
    lastTradeAt: '2024-01-20T13:45:00Z',
    riskLevel: 'low',
    strategy: {
      rsiThreshold: 65,
      adxThreshold: 30,
      bbWidthThreshold: 0.025,
      emaSlope: 0.3,
      atrPercentage: 2.0,
      vwapDistance: 1.0,
      momentumThreshold: 0.6,
      useMLPrediction: false,
      minSamplesForML: 50
    }
  },
  {
    id: '3',
    name: 'SOL Breakout',
    exchange: 'bybit',
    symbol: 'SOLUSDT',
    status: 'paused',
    leverage: 10,
    balance: 2000,
    pnl: 234.78,
    pnlPercentage: 11.74,
    totalTrades: 67,
    winRate: 76.1,
    createdAt: '2024-01-19T16:20:00Z',
    lastTradeAt: '2024-01-20T11:30:00Z',
    riskLevel: 'high',
    strategy: {
      rsiThreshold: 75,
      adxThreshold: 35,
      bbWidthThreshold: 0.03,
      emaSlope: 0.7,
      atrPercentage: 3.0,
      vwapDistance: 1.5,
      momentumThreshold: 1.0,
      useMLPrediction: true,
      minSamplesForML: 75
    }
  }
];

export const mockMarketData: MarketData[] = [
  {
    symbol: 'BTCUSDT',
    price: 42847.32,
    change24h: 2.34,
    volume24h: 1234567890,
    rsi: 68.5,
    adx: 28.3,
    bbWidth: 0.024,
    emaSlope: 0.45,
    atrPercentage: 2.8,
    vwapDistance: 1.1,
    momentum: 0.72
  },
  {
    symbol: 'ETHUSDT',
    price: 2634.78,
    change24h: -1.23,
    volume24h: 987654321,
    rsi: 45.2,
    adx: 22.1,
    bbWidth: 0.019,
    emaSlope: -0.2,
    atrPercentage: 2.1,
    vwapDistance: -0.8,
    momentum: -0.35
  },
  {
    symbol: 'SOLUSDT',
    price: 98.45,
    change24h: 5.67,
    volume24h: 456789123,
    rsi: 78.9,
    adx: 42.5,
    bbWidth: 0.035,
    emaSlope: 0.89,
    atrPercentage: 4.2,
    vwapDistance: 2.1,
    momentum: 1.24
  },
  {
    symbol: 'ADAUSDT',
    price: 0.4523,
    change24h: 0.89,
    volume24h: 234567890,
    rsi: 52.3,
    adx: 18.7,
    bbWidth: 0.016,
    emaSlope: 0.12,
    atrPercentage: 1.8,
    vwapDistance: 0.3,
    momentum: 0.15
  },
  {
    symbol: 'DOTUSDT',
    price: 6.78,
    change24h: -2.45,
    volume24h: 123456789,
    rsi: 38.1,
    adx: 15.2,
    bbWidth: 0.021,
    emaSlope: -0.35,
    atrPercentage: 2.3,
    vwapDistance: -1.2,
    momentum: -0.58
  },
  {
    symbol: 'AVAXUSDT',
    price: 34.56,
    change24h: 3.21,
    volume24h: 345678901,
    rsi: 61.7,
    adx: 26.8,
    bbWidth: 0.028,
    emaSlope: 0.52,
    atrPercentage: 3.1,
    vwapDistance: 1.4,
    momentum: 0.67
  }
];

export const mockTrades: Trade[] = [
  {
    id: '1',
    botId: '1',
    symbol: 'BTCUSDT',
    side: 'long',
    size: 0.1,
    entryPrice: 42500,
    exitPrice: 42847,
    pnl: 34.7,
    status: 'closed',
    timestamp: '2024-01-20T14:22:00Z',
    exchange: 'bybit'
  },
  {
    id: '2',
    botId: '2',
    symbol: 'ETHUSDT',
    side: 'short',
    size: 0.5,
    entryPrice: 2650,
    exitPrice: 2635,
    pnl: 7.5,
    status: 'closed',
    timestamp: '2024-01-20T13:45:00Z',
    exchange: 'okx'
  },
  {
    id: '3',
    botId: '1',
    symbol: 'BTCUSDT',
    side: 'long',
    size: 0.05,
    entryPrice: 42800,
    status: 'open',
    timestamp: '2024-01-20T15:10:00Z',
    exchange: 'bybit'
  }
];
